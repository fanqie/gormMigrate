package migrations

import (
	"fmt"
	"github.com/fanqie/gormMigrate/pkg"
)

func Register(migrate *pkg.GormMigrate) {
	fmt.Println("register migrate beging")

	fmt.Println("register migrate end")
}
